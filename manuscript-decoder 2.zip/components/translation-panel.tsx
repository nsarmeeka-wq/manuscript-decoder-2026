'use client'

import { useEffect, useRef, useState } from 'react'
import { Copy, Download, Globe2, Info, Languages, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Field, FieldDescription, FieldGroup, FieldLabel } from '@/components/ui/field'
import { downloadFile, type Manuscript } from '@/lib/manuscripts'
import { getTranslationLanguage, MAX_TRANSCRIPTION_LENGTH, translationLanguages, type TranslationLanguage } from '@/lib/translation-languages'

type TranslationPanelProps = {
  item: Manuscript
  language: TranslationLanguage
  onLanguageChange: (language: TranslationLanguage) => void
  onTranslation: (language: TranslationLanguage, text: string) => void
}

export function TranslationPanel({ item, language, onLanguageChange, onTranslation }: TranslationPanelProps) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const controller = useRef<AbortController | null>(null)
  const target = getTranslationLanguage(language)!
  const translation = item.translations[language] || ''
  const tooLong = item.text.trim().length > MAX_TRANSCRIPTION_LENGTH
  const canTranslate = Boolean(item.text.trim()) && !tooLong

  useEffect(() => () => { controller.current?.abort() }, [])

  function cancel() {
    controller.current?.abort()
    controller.current = null
    setBusy(false)
  }

  function changeLanguage(value: TranslationLanguage) {
    cancel()
    setError('')
    onLanguageChange(value)
  }

  async function translate() {
    if (!canTranslate || controller.current) return
    const current = new AbortController()
    controller.current = current
    setBusy(true)
    setError('')
    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: item.text, sourceLanguage: item.language.slice(0, 80), language }),
        signal: AbortSignal.any([current.signal, AbortSignal.timeout(55_000)]),
      })
      const result = await response.json().catch(() => null)
      if (!response.ok) throw new Error(result?.error || 'Translation failed. Please try again.')
      if (typeof result?.translation !== 'string' || !result.translation.trim() || result.language !== language) {
        throw new Error('An incomplete translation was returned. Please try again.')
      }
      if (current.signal.aborted) return
      onTranslation(language, result.translation)
      toast.success(`${language} translation ready`)
    } catch (err) {
      if (current.signal.aborted) return
      setError(err instanceof Error && err.name === 'TimeoutError'
        ? 'Translation took too long. Please try again.'
        : err instanceof Error ? err.message : 'Translation failed. Please try again.')
    } finally {
      if (controller.current === current) {
        controller.current = null
        setBusy(false)
      }
    }
  }

  async function copyTranslation() {
    try {
      await navigator.clipboard.writeText(translation)
      toast.success(`${language} translation copied`)
    } catch {
      toast.error('Clipboard unavailable. Select the translation and copy it manually.')
    }
  }

  return (
    <section id="modern-translation" aria-labelledby="translation-title" className="panel min-w-0 scroll-mt-6 overflow-hidden">
      <header className="panel-heading flex-wrap gap-3">
        <h2 id="translation-title" className="flex items-center gap-2"><Globe2 className="size-4 text-primary" />Modern translation</h2>
        <Badge variant="outline">Live AI · {translationLanguages.length} languages</Badge>
      </header>
      <div className="p-5">
        <div className="flex flex-col gap-5">
          <p className="text-sm leading-relaxed text-muted-foreground">Discover the meaning in your language. Translate the transcription into clear, everyday words.</p>
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="translation-language">Translate into</FieldLabel>
              <select id="translation-language" aria-label="Translation language" value={language} onChange={event => changeLanguage(event.target.value as TranslationLanguage)} className="h-11 w-full min-w-0 px-3 font-sans text-sm">
                {translationLanguages.map(option => <option key={option.code} value={option.name}>{option.name}{option.nativeName !== option.name ? ` · ${option.nativeName}` : ''}</option>)}
              </select>
              <FieldDescription>Translate after decoding, or edit the transcription first.</FieldDescription>
            </Field>
          </FieldGroup>
          <div className="no-print flex flex-wrap items-center gap-3">
            <Button size="lg" disabled={busy || !canTranslate} onClick={translate}>
              {busy ? <Loader2 data-icon="inline-start" className="animate-spin" /> : <Languages data-icon="inline-start" />}
              {busy ? `Translating to ${language}…` : translation ? 'Translate again' : `Translate to ${language}`}
            </Button>
            {busy && <Button variant="ghost" onClick={cancel}>Cancel</Button>}
          </div>
          {(!canTranslate) && <p role="status" className="text-sm text-muted-foreground">{tooLong ? `Translate up to ${MAX_TRANSCRIPTION_LENGTH.toLocaleString('en-US')} characters at a time. Shorten the transcription to continue.` : 'Add text to the transcription before translating.'}</p>}
          {error && <Alert variant="destructive"><Info /><AlertTitle>Translation unavailable</AlertTitle><AlertDescription>{error} Your transcription has not been changed.</AlertDescription></Alert>}
          <div aria-live="polite" aria-atomic="true" className="sr-only">{busy ? `Translating into ${language}.` : translation ? `${language} translation available.` : `Ready to translate into ${language}.`}</div>
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="translated-text">{language} translation</FieldLabel>
              <textarea id="translated-text" aria-label="Editable translation" aria-busy={busy} readOnly={busy || !translation} lang={target.code} dir={target.direction} value={translation} onChange={event => onTranslation(language, event.target.value)} placeholder={busy ? 'Your translation will appear here…' : 'Choose a language and select Translate to begin.'} className="min-h-44 w-full resize-y bg-background p-4 text-start font-sans text-base leading-relaxed text-foreground" />
              <FieldDescription>Changing the original text clears its translations. Generate a new translation to reflect your edits.</FieldDescription>
            </Field>
          </FieldGroup>
          <div className="no-print flex flex-wrap items-center gap-2">
            <Button variant="outline" disabled={!translation || busy} onClick={copyTranslation}><Copy data-icon="inline-start" />Copy translation</Button>
            <Button variant="outline" disabled={!translation || busy} onClick={() => downloadFile(translation, `manuscript-translation-${target.code}.txt`)}><Download data-icon="inline-start" />Download TXT</Button>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">AI-generated translations may contain mistakes, especially in ancient or damaged text. For cultural context or research, ask a qualified guide or specialist.</p>
          <p className="text-sm leading-relaxed text-muted-foreground">Selecting Translate sends the transcription to an AI service. Images are not sent. Export translations before refreshing.</p>
        </div>
      </div>
    </section>
  )
}
