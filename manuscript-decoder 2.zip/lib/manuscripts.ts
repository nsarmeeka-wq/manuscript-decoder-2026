export type Script = 'Devanagari' | 'Tamil' | 'Bengali'
export type Manuscript = {
  id: string
  title: string
  script: Script
  language: string
  subject: string
  period: string
  location: string
  image: string
  text: string
  translations: Record<string, string>
  confidence: number
  date: string
}
export const manuscripts: Manuscript[] = [
  {
    id: 'ayurveda', title: 'The art of healing', script: 'Devanagari', language: 'Sanskrit', subject: 'Ayurveda', period: '18th century', location: 'Varanasi, India', image: '/images/sanskrit-manuscript.png',
    text: 'सर्वे भवन्तु सुखिनः। सर्वे सन्तु निरामयाः।\nसर्वे भद्राणि पश्यन्तु। मा कश्चिद्दुःखभाग्भवेत्॥',
    translations: {},
    confidence: 94, date: '2026-09-09',
  },
  {
    id: 'tamil', title: 'Wisdom on a palm leaf', script: 'Tamil', language: 'Tamil', subject: 'Philosophy', period: '17th century', location: 'Thanjavur, India', image: '/images/tamil-manuscript.png',
    text: 'அகர முதல எழுத்தெல்லாம் ஆதி\nபகவன் முதற்றே உலகு.',
    translations: {},
    confidence: 92, date: '2026-09-08',
  },
  {
    id: 'bengali', title: 'Verses across centuries', script: 'Bengali', language: 'Bengali', subject: 'Literature', period: '19th century', location: 'Kolkata, India', image: '/images/bengali-manuscript.png',
    text: 'চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির,\nজ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর',
    translations: {},
    confidence: 96, date: '2026-09-07',
  },
]
export function downloadFile(content: string, name: string, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([content], { type }))
  const link = document.createElement('a')
  link.href = url
  link.download = name
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
