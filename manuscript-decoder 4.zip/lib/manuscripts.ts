export const translationLanguages = [
  { name: 'English', code: 'en', direction: 'ltr' },
  { name: 'Spanish', code: 'es', direction: 'ltr' },
  { name: 'French', code: 'fr', direction: 'ltr' },
  { name: 'German', code: 'de', direction: 'ltr' },
  { name: 'Portuguese', code: 'pt', direction: 'ltr' },
  { name: 'Arabic', code: 'ar', direction: 'rtl' },
  { name: 'Chinese', code: 'zh-Hans', direction: 'ltr' },
  { name: 'Japanese', code: 'ja', direction: 'ltr' },
  { name: 'Korean', code: 'ko', direction: 'ltr' },
  { name: 'Hindi', code: 'hi', direction: 'ltr' },
  { name: 'Tamil', code: 'ta', direction: 'ltr' },
] as const
export type TranslationLanguage = typeof translationLanguages[number]['name']
export function translationLocale(language: TranslationLanguage) {
  return translationLanguages.find(option => option.name === language)!
}
export type Script = 'Devanagari' | 'Tamil' | 'Bengali'
export type Manuscript = {
  id: string
  title: string
  script: Script
  language: string
  subject: string
  period: string
  location: string
  image: string
  text: string
  translations: Record<TranslationLanguage, string>
  preferredTranslation?: TranslationLanguage
  confidence: number
  date: string
}
export const manuscripts: Manuscript[] = [
  {
    id: 'ayurveda', title: 'The art of healing', script: 'Devanagari', language: 'Sanskrit', subject: 'Ayurveda', period: '18th century', location: 'Varanasi, India', image: '/images/sanskrit-manuscript.png',
    text: 'सर्वे भवन्तु सुखिनः। सर्वे सन्तु निरामयाः।\nसर्वे भद्राणि पश्यन्तु। मा कश्चिद्दुःखभाग्भवेत्॥',
    translations: {
      Spanish: 'Que todos sean felices. Que todos estén libres de enfermedades. Que todos vean lo auspicioso. Que nadie sufra.',
      French: 'Que tous soient heureux. Que tous soient exempts de maladie. Que tous voient ce qui est de bon augure. Que personne ne souffre.',
      German: 'Mögen alle glücklich sein. Mögen alle frei von Krankheit sein. Mögen alle das Heilvolle sehen. Möge niemand leiden.',
      Portuguese: 'Que todos sejam felizes. Que todos estejam livres de doenças. Que todos vejam o que é auspicioso. Que ninguém sofra.',
      Arabic: 'ليكن الجميع سعداء. وليكن الجميع معافين من المرض. وليرَ الجميع ما فيه الخير. وألّا يعاني أحد.',
      Chinese: '愿所有人幸福。愿所有人远离疾病。愿所有人见到吉祥美好之事。愿无人受苦。',
      Japanese: 'すべての人が幸せでありますように。すべての人が病から解き放たれますように。すべての人が幸いなものを目にしますように。誰も苦しむことがありませんように。',
      Korean: '모든 이가 행복하기를. 모든 이가 질병에서 벗어나기를. 모든 이가 상서로운 것을 보기를. 그 누구도 고통받지 않기를.',
      English: 'May all be happy. May all be free from illness. May all see what is auspicious. May no one suffer.', Hindi: 'सभी सुखी हों। सभी रोगमुक्त हों। सभी शुभ देखें। कोई भी दुःख का भागी न बने।', Tamil: 'அனைவரும் மகிழ்ச்சியாக இருக்கட்டும். அனைவரும் நோயின்றி இருக்கட்டும். அனைவரும் நன்மையைக் காணட்டும். யாரும் துன்பப்படாதிருக்கட்டும்.' },
    confidence: 94, date: '2026-09-09',
  },
  {
    id: 'tamil', title: 'Wisdom on a palm leaf', script: 'Tamil', language: 'Tamil', subject: 'Philosophy', period: '17th century', location: 'Thanjavur, India', image: '/images/tamil-manuscript.png',
    text: 'அகர முதல எழுத்தெல்லாம் ஆதி\nபகவன் முதற்றே உலகு.',
    translations: {
      Spanish: 'Así como la letra A es la primera de todas las letras, el Eterno es el primero en el mundo.',
      French: 'De même que la lettre A est la première de toutes les lettres, ainsi l’Éternel est le premier dans le monde.',
      German: 'Wie der Buchstabe A der erste aller Buchstaben ist, so steht der Ewige am Anfang der Welt.',
      Portuguese: 'Assim como a letra A é a primeira de todas as letras, o Eterno é o primeiro no mundo.',
      Arabic: 'كما أن حرف الألف هو أول الحروف، فإن الإله الأزلي هو الأول في العالم.',
      Chinese: '正如字母 A 是所有字母之首，永恒的神也是世界之始。',
      Japanese: '文字 A がすべての文字の始まりであるように、永遠なる神は世界の始まりである。',
      Korean: '글자 A가 모든 글자의 시작이듯, 영원한 신은 세상의 시작이다.',
      English: 'As the letter A is the first of all letters, so the Eternal is first in the world.', Hindi: 'जैसे अक्षरों में अ प्रथम है, वैसे ही संसार में आदि भगवान प्रथम हैं।', Tamil: 'எழுத்துகள் அனைத்துக்கும் அகரம் முதலானது. அதுபோல உலகத்துக்கு ஆதிபகவன் முதல்வன்.' },
    confidence: 92, date: '2026-09-08',
  },
  {
    id: 'bengali', title: 'Verses across centuries', script: 'Bengali', language: 'Bengali', subject: 'Literature', period: '19th century', location: 'Kolkata, India', image: '/images/bengali-manuscript.png',
    text: 'চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির,\nজ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর',
    translations: {
      Spanish: 'Donde la mente está libre de miedo y la cabeza se mantiene erguida; donde el conocimiento es libre; donde los muros del hogar…',
      French: 'Là où l’esprit est sans peur et la tête haute ; là où le savoir est libre ; là où les murs du foyer…',
      German: 'Wo der Geist ohne Furcht ist und der Kopf hoch erhoben; wo das Wissen frei ist; wo die Mauern des Hauses…',
      Portuguese: 'Onde a mente não tem medo e a cabeça se mantém erguida; onde o conhecimento é livre; onde as paredes do lar…',
      Arabic: 'حيث يكون العقل بلا خوف والرأس مرفوعًا؛ حيث تكون المعرفة حرة؛ حيث جدران البيت…',
      Chinese: '在那里，心灵无所畏惧，头颅高高昂起；在那里，知识自由；在那里，家园的围墙……',
      Japanese: '心に恐れがなく、頭が高く上げられるところ。知識が自由であるところ。家の壁が……',
      Korean: '마음에 두려움이 없고 고개를 높이 드는 곳, 지식이 자유로운 곳, 집의 벽이…',
      English: 'Where the mind is without fear and the head is held high; where knowledge is free; where the walls of the home…', Hindi: 'जहाँ मन भय से मुक्त है और सिर ऊँचा है; जहाँ ज्ञान मुक्त है; जहाँ घर की दीवारें…', Tamil: 'மனம் அச்சமின்றியும் தலை நிமிர்ந்தும் இருக்கும் இடம்; அறிவு சுதந்திரமாக இருக்கும் இடம்; வீட்டின் சுவர்கள்…' },
    confidence: 96, date: '2026-09-07',
  },
]
export function downloadFile(content: string, name: string, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([content], { type }))
  const link = document.createElement('a')
  link.href = url
  link.download = name
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
