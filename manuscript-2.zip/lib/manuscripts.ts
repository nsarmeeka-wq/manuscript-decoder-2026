export type Script = 'Devanagari' | 'Tamil' | 'Bengali'
export type Manuscript = {
  id: string
  title: string
  script: Script
  language: string
  subject: string
  period: string
  location: string
  image: string
  text: string
  translations: Record<string, string>
  confidence: number
  date: string
}
export const manuscripts: Manuscript[] = [
  {
    id: 'ayurveda', title: 'The art of healing', script: 'Devanagari', language: 'Sanskrit', subject: 'Ayurveda', period: '18th century', location: 'Varanasi, India', image: '/images/sanskrit-manuscript.png',
    text: 'सर्वे भवन्तु सुखिनः। सर्वे सन्तु निरामयाः।\nसर्वे भद्राणि पश्यन्तु। मा कश्चिद्दुःखभाग्भवेत्॥',
    translations: { English: 'May all be happy. May all be free from illness. May all see what is auspicious. May no one suffer.', Hindi: 'सभी सुखी हों। सभी रोगमुक्त हों। सभी शुभ देखें। कोई भी दुःख का भागी न बने।', Tamil: 'அனைவரும் மகிழ்ச்சியாக இருக்கட்டும். அனைவரும் நோயின்றி இருக்கட்டும். அனைவரும் நன்மையைக் காணட்டும். யாரும் துன்பப்படாதிருக்கட்டும்.' },
    confidence: 94, date: '2026-09-09',
  },
  {
    id: 'tamil', title: 'Wisdom on a palm leaf', script: 'Tamil', language: 'Tamil', subject: 'Philosophy', period: '17th century', location: 'Thanjavur, India', image: '/images/tamil-manuscript.png',
    text: 'அகர முதல எழுத்தெல்லாம் ஆதி\nபகவன் முதற்றே உலகு.',
    translations: { English: 'As the letter A is the first of all letters, so the Eternal is first in the world.', Hindi: 'जैसे अक्षरों में अ प्रथम है, वैसे ही संसार में आदि भगवान प्रथम हैं।', Tamil: 'எழுத்துகள் அனைத்துக்கும் அகரம் முதலானது. அதுபோல உலகத்துக்கு ஆதிபகவன் முதல்வன்.' },
    confidence: 92, date: '2026-09-08',
  },
  {
    id: 'bengali', title: 'Verses across centuries', script: 'Bengali', language: 'Bengali', subject: 'Literature', period: '19th century', location: 'Kolkata, India', image: '/images/bengali-manuscript.png',
    text: 'চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির,\nজ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর',
    translations: { English: 'Where the mind is without fear and the head is held high; where knowledge is free; where the walls of the home…', Hindi: 'जहाँ मन भय से मुक्त है और सिर ऊँचा है; जहाँ ज्ञान मुक्त है; जहाँ घर की दीवारें…', Tamil: 'மனம் அச்சமின்றியும் தலை நிமிர்ந்தும் இருக்கும் இடம்; அறிவு சுதந்திரமாக இருக்கும் இடம்; வீட்டின் சுவர்கள்…' },
    confidence: 96, date: '2026-09-07',
  },
]
export function downloadFile(content: string, name: string, type = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([content], { type }))
  const link = document.createElement('a')
  link.href = url
  link.download = name
  link.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}
